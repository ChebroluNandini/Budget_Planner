import { useAuth } from "./context/AuthContext.jsx";
import { BudgetProvider } from "./context/BudgetContext.jsx";
import AuthPage from "./pages/AuthPage/AuthPage.jsx";
import Header from "./components/Header/Header.jsx";
import SummaryCards from "./components/SummaryCards/SummaryCards.jsx";
import SpendingHistory from "./components/SpendingHistory/SpendingHistory.jsx";
import SpendingChart from "./components/SpendingChart/SpendingChart.jsx";
import SubscriptionTracker from "./components/SubscriptionTracker/SubscriptionTracker.jsx";
import SmartNotifications from "./components/SmartNotifications/SmartNotifications.jsx";
import BudgetLimit from "./components/BudgetLimit/BudgetLimit.jsx";
import TransactionForm from "./components/TransactionForm/TransactionForm.jsx";
import CategoryBreakdown from "./components/CategoryBreakdown/CategoryBreakdown.jsx";
import TransactionList from "./components/TransactionList/TransactionList.jsx";
import "./App.css";

export default function App() {
  const { user, loading } = useAuth();

  if (loading) return null;
  if (!user) return <AuthPage />;

  // key forces a fresh budget state when a different user logs in
  return (
    <BudgetProvider key={user.email} userId={user.email}>
      <div className="app">
        <Header />
        <main className="app__main">
          <SummaryCards />
          <SpendingHistory />
          <SpendingChart />
          <div className="app__grid">
            <div className="app__col">
              <TransactionForm />
              <BudgetLimit />
            </div>
            <div className="app__col">
              <CategoryBreakdown />
              <TransactionList />
            </div>
          </div>
          <SmartNotifications />
          <SubscriptionTracker />
        </main>
      </div>
    </BudgetProvider>
  );
}
