import { useEffect, useRef, useState } from "react";
import AuthLayout from "../../components/AuthLayout/AuthLayout.jsx";
import { useAuth } from "../../context/AuthContext.jsx";
import "./LoginPage.css";

export default function LoginPage({ onSwitch }) {
  const { login } = useAuth();
  const [form, setForm] = useState({ email: "", password: "" });
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState("");
  const [submitting, setSubmitting] = useState(false);
  const emailRef = useRef(null);

  useEffect(() => {
    emailRef.current?.focus();
  }, []);

  const handleChange = (e) => setForm({ ...form, [e.target.name]: e.target.value });

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!form.email.trim() || !form.password) {
      setError("Please enter your email and password.");
      return;
    }
    setSubmitting(true);
    const result = await login(form);
    setSubmitting(false);
    if (!result.ok) setError(result.error);
  };

  return (
    <AuthLayout
      title="Welcome back"
      subtitle="Log in to see your budget."
      footer={
        <>
          New here?{" "}
          <button type="button" onClick={onSwitch}>
            Create an account
          </button>
        </>
      }
    >
      <form className="login" onSubmit={handleSubmit} noValidate>
        <label className="login__field">
          Email
          <input
            ref={emailRef}
            name="email"
            type="email"
            autoComplete="email"
            value={form.email}
            onChange={handleChange}
            placeholder="you@example.com"
          />
        </label>

        <label className="login__field">
          Password
          <div className="login__password">
            <input
              name="password"
              type={showPassword ? "text" : "password"}
              autoComplete="current-password"
              value={form.password}
              onChange={handleChange}
              placeholder="Your password"
            />
            <button
              type="button"
              className="login__toggle"
              onClick={() => setShowPassword((s) => !s)}
            >
              {showPassword ? "Hide" : "Show"}
            </button>
          </div>
        </label>

        {error && <p className="login__error">{error}</p>}

        <button className="login__submit" type="submit" disabled={submitting}>
          {submitting ? "Logging in..." : "Log In"}
        </button>
      </form>
    </AuthLayout>
  );
}
