import { useState } from "react";
import LoginPage from "../LoginPage/LoginPage.jsx";
import RegisterPage from "../RegisterPage/RegisterPage.jsx";

// Switches between the login and registration pages
export default function AuthPage() {
  const [mode, setMode] = useState("login");

  return mode === "login" ? (
    <LoginPage onSwitch={() => setMode("register")} />
  ) : (
    <RegisterPage onSwitch={() => setMode("login")} />
  );
}
