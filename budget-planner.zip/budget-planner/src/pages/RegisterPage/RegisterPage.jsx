import { useEffect, useRef, useState } from "react";
import AuthLayout from "../../components/AuthLayout/AuthLayout.jsx";
import { useAuth } from "../../context/AuthContext.jsx";
import "./RegisterPage.css";

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

function validate({ name, email, password, confirm }) {
  const errors = {};
  if (!name.trim()) errors.name = "Name is required.";
  if (!EMAIL_RE.test(email.trim())) errors.email = "Enter a valid email address.";
  if (password.length < 6) errors.password = "Password must be at least 6 characters.";
  if (confirm !== password) errors.confirm = "Passwords do not match.";
  return errors;
}

export default function RegisterPage({ onSwitch }) {
  const { register } = useAuth();
  const [form, setForm] = useState({ name: "", email: "", password: "", confirm: "" });
  const [errors, setErrors] = useState({});
  const [serverError, setServerError] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const nameRef = useRef(null);

  useEffect(() => {
    nameRef.current?.focus();
  }, []);

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
    setErrors({ ...errors, [e.target.name]: undefined });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    const found = validate(form);
    setErrors(found);
    setServerError("");
    if (Object.keys(found).length) return;

    setSubmitting(true);
    const result = await register(form);
    setSubmitting(false);
    if (!result.ok) setServerError(result.error);
  };

  return (
    <AuthLayout
      title="Create your account"
      subtitle="Start planning your budget in a minute."
      footer={
        <>
          Already have an account?{" "}
          <button type="button" onClick={onSwitch}>
            Log in
          </button>
        </>
      }
    >
      <form className="register" onSubmit={handleSubmit} noValidate>
        <label className="register__field">
          Full name
          <input
            ref={nameRef}
            name="name"
            autoComplete="name"
            value={form.name}
            onChange={handleChange}
            placeholder="Your name"
          />
          {errors.name && <span className="register__hint">{errors.name}</span>}
        </label>

        <label className="register__field">
          Email
          <input
            name="email"
            type="email"
            autoComplete="email"
            value={form.email}
            onChange={handleChange}
            placeholder="you@example.com"
          />
          {errors.email && <span className="register__hint">{errors.email}</span>}
        </label>

        <label className="register__field">
          Password
          <div className="register__password">
            <input
              name="password"
              type={showPassword ? "text" : "password"}
              autoComplete="new-password"
              value={form.password}
              onChange={handleChange}
              placeholder="At least 6 characters"
            />
            <button
              type="button"
              className="register__toggle"
              onClick={() => setShowPassword((s) => !s)}
            >
              {showPassword ? "Hide" : "Show"}
            </button>
          </div>
          {errors.password && <span className="register__hint">{errors.password}</span>}
        </label>

        <label className="register__field">
          Confirm password
          <input
            name="confirm"
            type={showPassword ? "text" : "password"}
            autoComplete="new-password"
            value={form.confirm}
            onChange={handleChange}
            placeholder="Re-enter password"
          />
          {errors.confirm && <span className="register__hint">{errors.confirm}</span>}
        </label>

        {serverError && <p className="register__error">{serverError}</p>}

        <button className="register__submit" type="submit" disabled={submitting}>
          {submitting ? "Creating account..." : "Create Account"}
        </button>
      </form>
    </AuthLayout>
  );
}
