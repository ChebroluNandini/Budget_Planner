import { useMemo, useState } from "react";
import { useBudget } from "../../context/BudgetContext.jsx";
import "./SmartNotifications.css";

const EXTRA_MONTHLY_SAVINGS = 500;

function getGoalDraft(goal) {
  return {
    targetAmount: goal.targetAmount > 0 ? String(goal.targetAmount) : "",
    currentSavings: String(goal.currentSavings ?? 0),
    monthlyContribution: String(goal.monthlyContribution ?? 0),
  };
}

export default function SmartNotifications() {
  const {
    transactions,
    monthlyBudget,
    monthlyExpenses,
    savingsGoal,
    currencySymbol,
    format,
    dispatch,
  } = useBudget();
  const now = new Date();
  const currentYear = now.getFullYear();
  const currentMonth = now.getMonth();
  const [goalDraft, setGoalDraft] = useState(() => getGoalDraft(savingsGoal));
  const [feedback, setFeedback] = useState(null);

  const categoryChanges = useMemo(() => {
    const currentMonthExpenses = new Map();
    const previousMonthExpenses = new Map();
    const previousMonth = new Date(currentYear, currentMonth - 1, 1);

    transactions.forEach((transaction) => {
      if (transaction.type !== "expense") return;
      const date = new Date(transaction.date);
      if (Number.isNaN(date.getTime())) return;

      const target =
        date.getFullYear() === currentYear && date.getMonth() === currentMonth
          ? currentMonthExpenses
          : date.getFullYear() === previousMonth.getFullYear() &&
              date.getMonth() === previousMonth.getMonth()
            ? previousMonthExpenses
            : null;

      if (target) {
        target.set(
          transaction.category,
          (target.get(transaction.category) || 0) + transaction.amount
        );
      }
    });

    return Array.from(currentMonthExpenses.entries())
      .map(([category, amount]) => {
        const previousAmount = previousMonthExpenses.get(category) || 0;
        return {
          category,
          amount,
          previousAmount,
          increasePercent:
            previousAmount > 0 ? ((amount - previousAmount) / previousAmount) * 100 : 0,
        };
      })
      .filter(
        (category) =>
          category.previousAmount > 0 && category.increasePercent >= 10
      )
      .sort(
        (a, b) =>
          b.amount - b.previousAmount - (a.amount - a.previousAmount)
      )
      .slice(0, 3);
  }, [transactions, currentYear, currentMonth]);

  const handleGoalChange = (event) => {
    const { name, value } = event.target;
    setGoalDraft((previous) => ({ ...previous, [name]: value }));
    setFeedback(null);
  };

  const handleGoalSubmit = (event) => {
    event.preventDefault();
    const goal = {
      targetAmount: parseFloat(goalDraft.targetAmount),
      currentSavings: parseFloat(goalDraft.currentSavings),
      monthlyContribution: parseFloat(goalDraft.monthlyContribution),
    };

    if (
      !Number.isFinite(goal.targetAmount) ||
      goal.targetAmount <= 0 ||
      !Number.isFinite(goal.currentSavings) ||
      goal.currentSavings < 0 ||
      !Number.isFinite(goal.monthlyContribution) ||
      goal.monthlyContribution < 0
    ) {
      setFeedback({ type: "error", message: "Enter valid savings goal amounts." });
      return;
    }

    dispatch({ type: "SET_SAVINGS_GOAL", payload: goal });
    setGoalDraft(getGoalDraft(goal));
    setFeedback({ type: "success", message: "Savings goal saved." });
  };

  const notifications = [];
  if (monthlyBudget > 0 && monthlyExpenses >= monthlyBudget) {
    notifications.push({
      tone: "danger",
      message: `You have exceeded your monthly budget by ${format(
        monthlyExpenses - monthlyBudget
      )}.`,
    });
  } else if (monthlyBudget > 0 && monthlyExpenses / monthlyBudget >= 0.8) {
    notifications.push({
      tone: "warning",
      message: `You are close to your monthly budget, with ${format(
        monthlyBudget - monthlyExpenses
      )} remaining.`,
    });
  }

  categoryChanges.forEach((change) => {
    notifications.push({
      tone: "insight",
      message: `Your ${change.category.toLowerCase()} expenses increased by ${Math.round(
        change.increasePercent
      )}% compared to last month (${format(change.previousAmount)} to ${format(
        change.amount
      )}).`,
    });
  });

  const targetAmount = savingsGoal.targetAmount;
  const currentSavings = savingsGoal.currentSavings;
  const monthlyContribution = savingsGoal.monthlyContribution;
  if (targetAmount > 0 && currentSavings >= targetAmount) {
    notifications.push({
      tone: "success",
      message: "You have reached your savings goal. Congratulations!",
    });
  } else if (targetAmount > currentSavings) {
    const amountRemaining = targetAmount - currentSavings;
    const extraSavings = EXTRA_MONTHLY_SAVINGS;
    const monthsWithExtra = Math.ceil(
      amountRemaining / (monthlyContribution + extraSavings)
    );
    const monthsAtCurrentPace =
      monthlyContribution > 0
        ? Math.ceil(amountRemaining / monthlyContribution)
        : Infinity;

    if (monthsWithExtra < monthsAtCurrentPace) {
      const soonerBy =
        monthsAtCurrentPace === Infinity
          ? null
          : monthsAtCurrentPace - monthsWithExtra;
      notifications.push({
        tone: "success",
        message:
          soonerBy === null
            ? `Saving an extra ${format(
                extraSavings
              )} per month could help you reach your savings goal in ${monthsWithExtra} ${
                monthsWithExtra === 1 ? "month" : "months"
              }.`
            : `You could reach your savings goal ${soonerBy} ${
                soonerBy === 1 ? "month" : "months"
              } earlier by saving an extra ${format(extraSavings)} per month.`,
      });
    }
  }

  return (
    <section className="smart-notifications" aria-labelledby="smart-notifications-title">
      <div className="smart-notifications__heading">
        <h2 className="smart-notifications__title" id="smart-notifications-title">
          Smart Financial Notifications
        </h2>
        <p>Personalized insights based on your transactions and savings goal</p>
      </div>

      {notifications.length > 0 ? (
        <ul className="smart-notifications__list" aria-live="polite">
          {notifications.map((notification, index) => (
            <li
              className={`smart-notifications__item smart-notifications__item--${notification.tone}`}
              key={`${notification.tone}-${index}`}
            >
              {notification.message}
            </li>
          ))}
        </ul>
      ) : (
        <p className="smart-notifications__empty">
          No new insights right now. Add transactions to get personalized updates.
        </p>
      )}

      <form className="smart-notifications__form" onSubmit={handleGoalSubmit}>
        <h3>Set your savings goal</h3>
        <div className="smart-notifications__fields">
          <label>
            Goal amount ({currencySymbol})
            <input
              name="targetAmount"
              type="number"
              min="0.01"
              step="any"
              value={goalDraft.targetAmount}
              onChange={handleGoalChange}
              required
            />
          </label>
          <label>
            Already saved ({currencySymbol})
            <input
              name="currentSavings"
              type="number"
              min="0"
              step="any"
              value={goalDraft.currentSavings}
              onChange={handleGoalChange}
              required
            />
          </label>
          <label>
            Monthly savings ({currencySymbol})
            <input
              name="monthlyContribution"
              type="number"
              min="0"
              step="any"
              value={goalDraft.monthlyContribution}
              onChange={handleGoalChange}
              required
            />
          </label>
          <button type="submit">Save goal</button>
        </div>
        {feedback && (
          <p
            className={`smart-notifications__feedback smart-notifications__feedback--${feedback.type}`}
            role={feedback.type === "error" ? "alert" : "status"}
          >
            {feedback.message}
          </p>
        )}
      </form>
    </section>
  );
}
