import "./AuthLayout.css";

export default function AuthLayout({ title, subtitle, children, footer }) {
  return (
    <div className="alayout">
      <div className="alayout__brand">
        <h1>💰 Budget Planner</h1>
        <p>Track income, control spending and hit your monthly goals.</p>
      </div>

      <div className="alayout__card">
        <h2 className="alayout__title">{title}</h2>
        <p className="alayout__subtitle">{subtitle}</p>
        {children}
        <div className="alayout__footer">{footer}</div>
      </div>
    </div>
  );
}
