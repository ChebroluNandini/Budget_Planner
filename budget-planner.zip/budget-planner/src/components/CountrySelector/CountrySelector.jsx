import { useBudget } from "../../context/BudgetContext.jsx";
import { COUNTRIES } from "../../utils/countries.js";
import "./CountrySelector.css";

export default function CountrySelector() {
  const { country, currencySymbol, dispatch } = useBudget();

  return (
    <label className="csel">
      <span className="csel__label">Country</span>
      <select
        className="csel__select"
        value={country.code}
        onChange={(e) => dispatch({ type: "SET_COUNTRY", payload: e.target.value })}
      >
        {COUNTRIES.map((c) => (
          <option key={c.code} value={c.code}>
            {c.name} ({c.currency})
          </option>
        ))}
      </select>
      <span className="csel__symbol" title={country.currency}>
        {currencySymbol}
      </span>
    </label>
  );
}
