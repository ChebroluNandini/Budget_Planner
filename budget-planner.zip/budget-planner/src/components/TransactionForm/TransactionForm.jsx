import { useRef, useState } from "react";
import { useBudget } from "../../context/BudgetContext.jsx";
import { EXPENSE_CATEGORIES, INCOME_CATEGORIES } from "../../utils/format.js";
import "./TransactionForm.css";

const emptyForm = {
  type: "expense",
  description: "",
  amount: "",
  category: "Food",
};

export default function TransactionForm() {
  const { dispatch, currencySymbol } = useBudget();
  const [form, setForm] = useState(emptyForm);
  const [error, setError] = useState("");
  const descRef = useRef(null); // focus the description field after submit

  const categories = form.type === "expense" ? EXPENSE_CATEGORIES : INCOME_CATEGORIES;

  const handleChange = (e) => {
    const { name, value } = e.target;
    setForm((prev) => {
      const next = { ...prev, [name]: value };
      if (name === "type") {
        next.category = value === "expense" ? EXPENSE_CATEGORIES[0] : INCOME_CATEGORIES[0];
      }
      return next;
    });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    const amount = parseFloat(form.amount);

    if (!form.description.trim()) {
      setError("Please enter a description.");
      descRef.current?.focus();
      return;
    }
    if (!amount || amount <= 0) {
      setError("Enter an amount greater than 0.");
      return;
    }

    dispatch({
      type: "ADD_TRANSACTION",
      payload: {
        id: crypto.randomUUID(),
        type: form.type,
        description: form.description.trim(),
        amount,
        category: form.category,
        date: new Date().toISOString(),
      },
    });

    setError("");
    setForm((prev) => ({ ...emptyForm, type: prev.type, category: prev.category }));
    descRef.current?.focus();
  };

  return (
    <form className="tform" onSubmit={handleSubmit}>
      <h2 className="tform__title">Add Transaction</h2>

      <div className="tform__toggle">
        {["expense", "income"].map((t) => (
          <button
            key={t}
            type="button"
            className={`tform__toggle-btn ${form.type === t ? `is-active is-${t}` : ""}`}
            onClick={() => handleChange({ target: { name: "type", value: t } })}
          >
            {t === "expense" ? "Expense" : "Income"}
          </button>
        ))}
      </div>

      <label className="tform__field">
        Description
        <input
          ref={descRef}
          name="description"
          value={form.description}
          onChange={handleChange}
          placeholder="e.g. Groceries"
        />
      </label>

      <div className="tform__row">
        <label className="tform__field">
          Amount ({currencySymbol})
          <input
            name="amount"
            type="number"
            min="0"
            step="any"
            value={form.amount}
            onChange={handleChange}
            placeholder="0"
          />
        </label>

        <label className="tform__field">
          Category
          <select name="category" value={form.category} onChange={handleChange}>
            {categories.map((c) => (
              <option key={c}>{c}</option>
            ))}
          </select>
        </label>
      </div>

      {error && <p className="tform__error">{error}</p>}

      <button className="tform__submit" type="submit">
        Add {form.type === "expense" ? "Expense" : "Income"}
      </button>
    </form>
  );
}
