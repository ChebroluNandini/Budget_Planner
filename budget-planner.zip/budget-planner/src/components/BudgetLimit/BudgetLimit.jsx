import { useEffect, useState } from "react";
import { useBudget } from "../../context/BudgetContext.jsx";
import "./BudgetLimit.css";

export default function BudgetLimit() {
  const { monthlyBudget, monthlyExpenses, format, dispatch } = useBudget();
  const [draft, setDraft] = useState(String(monthlyBudget));

  // Keep input in sync if the budget changes elsewhere
  useEffect(() => {
    setDraft(String(monthlyBudget));
  }, [monthlyBudget]);

  const percent = monthlyBudget > 0 ? (monthlyExpenses / monthlyBudget) * 100 : 0;
  const remaining = monthlyBudget - monthlyExpenses;
  const status = percent >= 100 ? "over" : percent >= 80 ? "warn" : "ok";
  const alert =
    percent >= 100
      ? {
          tone: "over",
          message:
            percent > 100
              ? "Monthly budget exceeded. Reduce spending to get back within your limit."
              : "100% of your monthly budget has been used.",
        }
      : percent >= 80
        ? {
            tone: "warn",
            message:
              "Warning: 80% of your monthly budget has been used. Spend carefully to avoid overspending.",
          }
        : percent >= 50
          ? {
              tone: "notice",
              message: "Heads up: 50% of your monthly budget has been used.",
            }
          : null;

  const save = (e) => {
    e.preventDefault();
    const value = parseFloat(draft);
    if (value > 0) dispatch({ type: "SET_BUDGET", payload: value });
  };

  return (
    <section className="blimit">
      <h2 className="blimit__title">Monthly Budget</h2>

      <form className="blimit__form" onSubmit={save}>
        <input
          type="number"
          min="0"
          value={draft}
          onChange={(e) => setDraft(e.target.value)}
          aria-label="Monthly budget"
        />
        <button type="submit">Set</button>
      </form>

      <div className="blimit__bar">
        <div
          className={`blimit__fill blimit__fill--${status}`}
          style={{ width: `${Math.min(percent, 100)}%` }}
        />
      </div>

      <p className="blimit__text">
        {format(monthlyExpenses)} spent of {format(monthlyBudget)} (
        {percent.toFixed(0)}%)
      </p>
      <p className={`blimit__remaining blimit__remaining--${status}`}>
        {remaining >= 0
          ? `${format(remaining)} left to spend`
          : `Over budget by ${format(Math.abs(remaining))}`}
      </p>
      {alert && (
        <p
          className={`blimit__alert blimit__alert--${alert.tone}`}
          role={alert.tone === "warn" || alert.tone === "over" ? "alert" : "status"}
        >
          {alert.message}
        </p>
      )}
    </section>
  );
}
