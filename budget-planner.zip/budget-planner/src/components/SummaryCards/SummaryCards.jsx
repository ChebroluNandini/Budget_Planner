import { useBudget } from "../../context/BudgetContext.jsx";
import "./SummaryCards.css";

export default function SummaryCards() {
  const { totals, format } = useBudget();

  const cards = [
    { label: "Income", value: totals.income, tone: "income" },
    { label: "Expenses", value: totals.expenses, tone: "expense" },
    {
      label: "Balance",
      value: totals.balance,
      tone: totals.balance >= 0 ? "income" : "expense",
    },
  ];

  return (
    <section className="summary">
      {cards.map((c) => (
        <div key={c.label} className="summary__card">
          <span className="summary__label">{c.label}</span>
          <strong className={`summary__value summary__value--${c.tone}`}>
            {format(c.value)}
          </strong>
        </div>
      ))}
    </section>
  );
}
