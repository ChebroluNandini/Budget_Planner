import { useState } from "react";
import { useBudget } from "../../context/BudgetContext.jsx";
import "./SubscriptionTracker.css";

const BILLING_OPTIONS = [
  { value: "weekly", label: "Weekly", renewalsPerYear: 52 },
  { value: "monthly", label: "Monthly", renewalsPerYear: 12 },
  { value: "quarterly", label: "Quarterly", renewalsPerYear: 4 },
  { value: "yearly", label: "Yearly", renewalsPerYear: 1 },
];

const emptyForm = {
  name: "",
  amount: "",
  frequency: "monthly",
  renewalDate: "",
};

function getAnnualCost(subscription) {
  const billingOption = BILLING_OPTIONS.find(
    (option) => option.value === subscription.frequency
  );
  return subscription.amount * billingOption.renewalsPerYear;
}

export default function SubscriptionTracker() {
  const { subscriptions, format, dispatch } = useBudget();
  const [form, setForm] = useState(emptyForm);
  const [error, setError] = useState("");

  const annualTotal = subscriptions.reduce(
    (total, subscription) => total + getAnnualCost(subscription),
    0
  );

  const sortedSubscriptions = [...subscriptions].sort((a, b) =>
    a.renewalDate.localeCompare(b.renewalDate)
  );

  const handleChange = (event) => {
    const { name, value } = event.target;
    setForm((previous) => ({ ...previous, [name]: value }));
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    const amount = parseFloat(form.amount);
    if (!form.name.trim()) {
      setError("Enter a subscription name.");
      return;
    }
    if (!Number.isFinite(amount) || amount <= 0) {
      setError("Enter a cost greater than 0.");
      return;
    }
    if (!form.renewalDate) {
      setError("Choose the next renewal date.");
      return;
    }

    dispatch({
      type: "ADD_SUBSCRIPTION",
      payload: {
        id: crypto.randomUUID(),
        name: form.name.trim(),
        amount,
        frequency: form.frequency,
        renewalDate: form.renewalDate,
      },
    });
    setForm(emptyForm);
    setError("");
  };

  return (
    <section className="subscriptions" aria-labelledby="subscriptions-title">
      <div className="subscriptions__header">
        <div>
          <h2 className="subscriptions__title" id="subscriptions-title">
            Subscription Tracker
          </h2>
          <p className="subscriptions__subtitle">
            Keep track of renewals and recurring costs
          </p>
        </div>
        <div className="subscriptions__annual">
          <span>Estimated yearly cost</span>
          <strong>{format(annualTotal)}</strong>
        </div>
      </div>

      <form className="subscriptions__form" onSubmit={handleSubmit}>
        <label className="subscriptions__field">
          Subscription
          <input
            name="name"
            value={form.name}
            onChange={handleChange}
            placeholder="e.g. Netflix"
            required
          />
        </label>
        <label className="subscriptions__field">
          Cost per billing period
          <input
            name="amount"
            type="number"
            min="0.01"
            step="any"
            value={form.amount}
            onChange={handleChange}
            required
          />
        </label>
        <label className="subscriptions__field">
          Billing frequency
          <select name="frequency" value={form.frequency} onChange={handleChange}>
            {BILLING_OPTIONS.map((option) => (
              <option key={option.value} value={option.value}>
                {option.label}
              </option>
            ))}
          </select>
        </label>
        <label className="subscriptions__field">
          Next renewal
          <input
            name="renewalDate"
            type="date"
            value={form.renewalDate}
            onChange={handleChange}
            required
          />
        </label>
        <button className="subscriptions__submit" type="submit">
          Add subscription
        </button>
      </form>

      {error && (
        <p className="subscriptions__error" role="alert">
          {error}
        </p>
      )}

      {sortedSubscriptions.length === 0 ? (
        <p className="subscriptions__empty">No subscriptions added yet.</p>
      ) : (
        <ul className="subscriptions__list">
          {sortedSubscriptions.map((subscription) => {
            const billingLabel = BILLING_OPTIONS.find(
              (option) => option.value === subscription.frequency
            ).label;
            const renewalDate = new Date(`${subscription.renewalDate}T00:00:00`);

            return (
              <li className="subscriptions__item" key={subscription.id}>
                <div className="subscriptions__info">
                  <strong>{subscription.name}</strong>
                  <span>
                    Renews {renewalDate.toLocaleDateString()} · {format(subscription.amount)}{" "}
                    {billingLabel.toLowerCase()}
                  </span>
                </div>
                <div className="subscriptions__cost">
                  <strong>{format(getAnnualCost(subscription))}</strong>
                  <span>per year</span>
                </div>
                <button
                  className="subscriptions__delete"
                  type="button"
                  aria-label={`Delete ${subscription.name} subscription`}
                  onClick={() =>
                    dispatch({
                      type: "DELETE_SUBSCRIPTION",
                      payload: subscription.id,
                    })
                  }
                >
                  Remove
                </button>
              </li>
            );
          })}
        </ul>
      )}
    </section>
  );
}
