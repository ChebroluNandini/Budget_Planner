import { useMemo } from "react";
import { useBudget } from "../../context/BudgetContext.jsx";
import "./SpendingHistory.css";

const MONTH_COUNT = 6;

export default function SpendingHistory() {
  const { transactions, format } = useBudget();
  const currentDate = new Date();
  const currentYear = currentDate.getFullYear();
  const currentMonth = currentDate.getMonth();

  const { yearSpend, months } = useMemo(() => {
    const monthlySpend = new Map();
    let yearTotal = 0;

    transactions.forEach((transaction) => {
      if (transaction.type !== "expense") return;

      const date = new Date(transaction.date);
      if (Number.isNaN(date.getTime())) return;

      const year = date.getFullYear();
      const month = date.getMonth();

      if (year === currentYear) {
        yearTotal += transaction.amount;
      }

      const key = `${year}-${month}`;
      monthlySpend.set(key, (monthlySpend.get(key) || 0) + transaction.amount);
    });

    const monthRows = Array.from({ length: MONTH_COUNT }, (_, index) => {
      const date = new Date(currentYear, currentMonth - (MONTH_COUNT - 1 - index), 1);
      const key = `${date.getFullYear()}-${date.getMonth()}`;

      return {
        key,
        label: date.toLocaleDateString(undefined, { month: "short", year: "numeric" }),
        amount: monthlySpend.get(key) || 0,
      };
    });

    return { yearSpend: yearTotal, months: monthRows };
  }, [transactions, currentYear, currentMonth]);

  const maxMonthlySpend = Math.max(...months.map((month) => month.amount), 0);

  return (
    <section className="spending-history" aria-labelledby="spending-history-title">
      <div className="spending-history__header">
        <div>
          <h2 className="spending-history__title" id="spending-history-title">
            Spending History
          </h2>
          <p className="spending-history__subtitle">
            Monthly expenses and your {currentYear} total
          </p>
        </div>
        <div className="spending-history__total">
          <span className="spending-history__label">Year to date</span>
          <strong>{format(yearSpend)}</strong>
        </div>
      </div>

      <ul className="spending-history__months">
        {months.map((month) => {
          const percentage = maxMonthlySpend
            ? (month.amount / maxMonthlySpend) * 100
            : 0;

          return (
            <li className="spending-history__month" key={month.key}>
              <div className="spending-history__month-label">
                <span>{month.label}</span>
                <span>{format(month.amount)}</span>
              </div>
              <div
                className="spending-history__bar"
                role="img"
                aria-label={`${month.label}: ${format(month.amount)} spent`}
              >
                <span style={{ width: `${percentage}%` }} />
              </div>
            </li>
          );
        })}
      </ul>
    </section>
  );
}
