import { useAuth } from "../../context/AuthContext.jsx";
import CountrySelector from "../CountrySelector/CountrySelector.jsx";
import "./Header.css";

export default function Header() {
  const { user, logout } = useAuth();
  const month = new Date().toLocaleString("en-IN", {
    month: "long",
    year: "numeric",
  });

  return (
    <header className="header">
      <div className="header__inner">
        <h1 className="header__title">💰 Budget Planner</h1>
        <div className="header__right">
          <CountrySelector />
          <span className="header__month">{month}</span>
          <span className="header__user">👤 {user.name}</span>
          <button className="header__logout" onClick={logout}>
            Log out
          </button>
        </div>
      </div>
    </header>
  );
}
