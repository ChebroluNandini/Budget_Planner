import { useMemo } from "react";
import { useBudget } from "../../context/BudgetContext.jsx";
import "./CategoryBreakdown.css";

export default function CategoryBreakdown() {
  const { transactions, totals, format } = useBudget();

  const rows = useMemo(() => {
    const map = {};
    transactions
      .filter((t) => t.type === "expense")
      .forEach((t) => {
        map[t.category] = (map[t.category] || 0) + t.amount;
      });
    return Object.entries(map)
      .map(([category, amount]) => ({ category, amount }))
      .sort((a, b) => b.amount - a.amount);
  }, [transactions]);

  return (
    <section className="cbreak">
      <h2 className="cbreak__title">Spending by Category</h2>

      {rows.length === 0 ? (
        <p className="cbreak__empty">No expenses yet.</p>
      ) : (
        <ul className="cbreak__list">
          {rows.map((r) => {
            const pct = totals.expenses ? (r.amount / totals.expenses) * 100 : 0;
            return (
              <li key={r.category} className="cbreak__item">
                <div className="cbreak__top">
                  <span>{r.category}</span>
                  <span>
                    {format(r.amount)} · {pct.toFixed(0)}%
                  </span>
                </div>
                <div className="cbreak__bar">
                  <div className="cbreak__fill" style={{ width: `${pct}%` }} />
                </div>
              </li>
            );
          })}
        </ul>
      )}
    </section>
  );
}
