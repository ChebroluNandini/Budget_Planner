import { useState } from "react";
import { useBudget } from "../../context/BudgetContext.jsx";
import "./TransactionList.css";

const FILTERS = ["all", "income", "expense"];

export default function TransactionList() {
  const { transactions, format, dispatch } = useBudget();
  const [filter, setFilter] = useState("all");

  const visible =
    filter === "all" ? transactions : transactions.filter((t) => t.type === filter);

  const handleClear = () => {
    if (window.confirm("Delete all transactions?")) {
      dispatch({ type: "CLEAR_ALL" });
    }
  };

  return (
    <section className="tlist">
      <div className="tlist__head">
        <h2 className="tlist__title">Transactions</h2>
        <div className="tlist__filters">
          {FILTERS.map((f) => (
            <button
              key={f}
              className={`tlist__filter ${filter === f ? "is-active" : ""}`}
              onClick={() => setFilter(f)}
            >
              {f}
            </button>
          ))}
        </div>
      </div>

      {visible.length === 0 ? (
        <p className="tlist__empty">Nothing to show yet.</p>
      ) : (
        <ul className="tlist__list">
          {visible.map((t) => (
            <li key={t.id} className="tlist__item">
              <div className="tlist__info">
                <strong>{t.description}</strong>
                <span>
                  {t.category} · {new Date(t.date).toLocaleDateString("en-IN")}
                </span>
              </div>
              <div className="tlist__right">
                <span className={`tlist__amount tlist__amount--${t.type}`}>
                  {t.type === "expense" ? "-" : "+"}
                  {format(t.amount)}
                </span>
                <button
                  className="tlist__delete"
                  onClick={() => dispatch({ type: "DELETE_TRANSACTION", payload: t.id })}
                  aria-label={`Delete ${t.description}`}
                >
                  ✕
                </button>
              </div>
            </li>
          ))}
        </ul>
      )}

      {transactions.length > 0 && (
        <button className="tlist__clear" onClick={handleClear}>
          Clear all
        </button>
      )}
    </section>
  );
}
