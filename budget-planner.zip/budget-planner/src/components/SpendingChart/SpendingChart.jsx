import { useMemo } from "react";
import { useBudget } from "../../context/BudgetContext.jsx";
import "./SpendingChart.css";

const MONTH_COUNT = 6;
const CHART = { width: 760, height: 260, left: 100, right: 24, top: 20, bottom: 52 };

export default function SpendingChart() {
  const { transactions, format } = useBudget();
  const now = new Date();
  const currentYear = now.getFullYear();
  const currentMonth = now.getMonth();

  const months = useMemo(() => {
    const totals = new Map();

    transactions.forEach((transaction) => {
      if (transaction.type !== "expense") return;
      const date = new Date(transaction.date);
      if (Number.isNaN(date.getTime())) return;

      const key = `${date.getFullYear()}-${date.getMonth()}`;
      totals.set(key, (totals.get(key) || 0) + transaction.amount);
    });

    return Array.from({ length: MONTH_COUNT }, (_, index) => {
      const date = new Date(
        currentYear,
        currentMonth - (MONTH_COUNT - 1 - index),
        1
      );
      const key = `${date.getFullYear()}-${date.getMonth()}`;

      return {
        key,
        label: date.toLocaleDateString(undefined, { month: "short" }),
        fullLabel: date.toLocaleDateString(undefined, {
          month: "long",
          year: "numeric",
        }),
        amount: totals.get(key) || 0,
      };
    });
  }, [transactions, currentYear, currentMonth]);

  const plotWidth = CHART.width - CHART.left - CHART.right;
  const plotHeight = CHART.height - CHART.top - CHART.bottom;
  const maxAmount = Math.max(...months.map((month) => month.amount), 0);
  const scaleMax = maxAmount || 1;
  const points = months.map((month, index) => ({
    ...month,
    x: CHART.left + (plotWidth * index) / (MONTH_COUNT - 1),
    y: CHART.top + plotHeight - (month.amount / scaleMax) * plotHeight,
  }));
  const pointList = points.map((point) => `${point.x},${point.y}`).join(" ");

  return (
    <section className="spending-chart" aria-labelledby="spending-chart-title">
      <h2 className="spending-chart__title" id="spending-chart-title">
        Spending Trend
      </h2>
      <p className="spending-chart__subtitle">Monthly expenses over the last six months</p>
      <div className="spending-chart__canvas">
        <svg
          className="spending-chart__svg"
          viewBox={`0 0 ${CHART.width} ${CHART.height}`}
          role="img"
          aria-label={`Monthly expense trend: ${points
            .map((point) => `${point.fullLabel}, ${format(point.amount)}`)
            .join("; ")}`}
        >
          {[0, 0.25, 0.5, 0.75, 1].map((fraction) => {
            const y = CHART.top + plotHeight * fraction;
            const amount = scaleMax * (1 - fraction);
            return (
              <g key={fraction}>
                <line
                  className="spending-chart__gridline"
                  x1={CHART.left}
                  x2={CHART.width - CHART.right}
                  y1={y}
                  y2={y}
                />
                <text className="spending-chart__tick" x={CHART.left - 10} y={y + 4}>
                  {format(amount)}
                </text>
              </g>
            );
          })}
          <polyline className="spending-chart__line" points={pointList} />
          {points.map((point) => (
            <g key={point.key}>
              <circle
                className="spending-chart__point"
                cx={point.x}
                cy={point.y}
                r="5"
              >
                <title>
                  {point.fullLabel}: {format(point.amount)}
                </title>
              </circle>
              <text
                className="spending-chart__month"
                x={point.x}
                y={CHART.height - 18}
              >
                {point.label}
              </text>
            </g>
          ))}
        </svg>
      </div>
    </section>
  );
}
