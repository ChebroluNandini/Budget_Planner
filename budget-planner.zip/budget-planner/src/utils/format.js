export const EXPENSE_CATEGORIES = [
  "Food",
  "Rent",
  "Transport",
  "Shopping",
  "Bills",
  "Health",
  "Entertainment",
  "Other",
];

export const INCOME_CATEGORIES = ["Salary", "Freelance", "Gift", "Other"];
