// code: ISO country code, currency: ISO 4217, locale: used for number formatting
export const COUNTRIES = [
  { code: "IN", name: "India", currency: "INR", locale: "en-IN", defaultBudget: 20000 },
  { code: "US", name: "United States", currency: "USD", locale: "en-US", defaultBudget: 2000 },
  { code: "GB", name: "United Kingdom", currency: "GBP", locale: "en-GB", defaultBudget: 1500 },
  { code: "DE", name: "Germany (Euro)", currency: "EUR", locale: "de-DE", defaultBudget: 1800 },
  { code: "FR", name: "France (Euro)", currency: "EUR", locale: "fr-FR", defaultBudget: 1800 },
  { code: "JP", name: "Japan", currency: "JPY", locale: "ja-JP", defaultBudget: 250000 },
  { code: "CN", name: "China", currency: "CNY", locale: "zh-CN", defaultBudget: 10000 },
  { code: "AE", name: "United Arab Emirates", currency: "AED", locale: "en-AE", defaultBudget: 7000 },
  { code: "SA", name: "Saudi Arabia", currency: "SAR", locale: "en-SA", defaultBudget: 7000 },
  { code: "CA", name: "Canada", currency: "CAD", locale: "en-CA", defaultBudget: 2500 },
  { code: "AU", name: "Australia", currency: "AUD", locale: "en-AU", defaultBudget: 2500 },
  { code: "SG", name: "Singapore", currency: "SGD", locale: "en-SG", defaultBudget: 2500 },
  { code: "CH", name: "Switzerland", currency: "CHF", locale: "de-CH", defaultBudget: 3000 },
  { code: "BR", name: "Brazil", currency: "BRL", locale: "pt-BR", defaultBudget: 5000 },
  { code: "ZA", name: "South Africa", currency: "ZAR", locale: "en-ZA", defaultBudget: 15000 },
  { code: "PK", name: "Pakistan", currency: "PKR", locale: "en-PK", defaultBudget: 60000 },
  { code: "BD", name: "Bangladesh", currency: "BDT", locale: "en-BD", defaultBudget: 30000 },
  { code: "LK", name: "Sri Lanka", currency: "LKR", locale: "en-LK", defaultBudget: 100000 },
];

export const getCountry = (code) =>
  COUNTRIES.find((c) => c.code === code) || COUNTRIES[0];

export const formatMoney = (amount, country) =>
  new Intl.NumberFormat(country.locale, {
    style: "currency",
    currency: country.currency,
    maximumFractionDigits: 0,
  }).format(amount);

export const getCurrencySymbol = (country) =>
  new Intl.NumberFormat(country.locale, {
    style: "currency",
    currency: country.currency,
  })
    .formatToParts(0)
    .find((p) => p.type === "currency")?.value ?? country.currency;
