import { createContext, useContext, useEffect, useMemo, useState } from "react";

// NOTE: This is a front-end-only demo. Accounts live in localStorage.
// For a real app, replace these functions with calls to a backend API.
const USERS_KEY = "bp-users";
const SESSION_KEY = "bp-session";

const readUsers = () => {
  try {
    return JSON.parse(localStorage.getItem(USERS_KEY)) || {};
  } catch {
    return {};
  }
};

const writeUsers = (users) => localStorage.setItem(USERS_KEY, JSON.stringify(users));

async function hashPassword(password, salt) {
  const data = new TextEncoder().encode(`${salt}:${password}`);
  const digest = await crypto.subtle.digest("SHA-256", data);
  return Array.from(new Uint8Array(digest))
    .map((b) => b.toString(16).padStart(2, "0"))
    .join("");
}

const AuthContext = createContext(null);

export function AuthProvider({ children }) {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);

  // Restore session on page load
  useEffect(() => {
    const email = localStorage.getItem(SESSION_KEY);
    const saved = email && readUsers()[email];
    if (saved) setUser({ name: saved.name, email: saved.email });
    setLoading(false);
  }, []);

  const register = async ({ name, email, password }) => {
    const key = email.trim().toLowerCase();
    const users = readUsers();
    if (users[key]) return { ok: false, error: "An account with this email already exists." };
    if (!crypto?.subtle) {
      return { ok: false, error: "Secure context required. Open the app on localhost or HTTPS." };
    }

    const salt = crypto.randomUUID();
    const passwordHash = await hashPassword(password, salt);
    users[key] = { name: name.trim(), email: key, salt, passwordHash };
    writeUsers(users);

    localStorage.setItem(SESSION_KEY, key);
    setUser({ name: name.trim(), email: key });
    return { ok: true };
  };

  const login = async ({ email, password }) => {
    const key = email.trim().toLowerCase();
    const found = readUsers()[key];
    if (!found) return { ok: false, error: "Invalid email or password." };
    if (!crypto?.subtle) {
      return { ok: false, error: "Secure context required. Open the app on localhost or HTTPS." };
    }

    const hash = await hashPassword(password, found.salt);
    if (hash !== found.passwordHash) return { ok: false, error: "Invalid email or password." };

    localStorage.setItem(SESSION_KEY, key);
    setUser({ name: found.name, email: found.email });
    return { ok: true };
  };

  const logout = () => {
    localStorage.removeItem(SESSION_KEY);
    setUser(null);
  };

  const value = useMemo(
    () => ({ user, loading, register, login, logout }),
    [user, loading]
  );

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error("useAuth must be used inside <AuthProvider>");
  return ctx;
}
