import { createContext, useContext, useEffect, useMemo, useReducer } from "react";
import {
  COUNTRIES,
  formatMoney,
  getCountry,
  getCurrencySymbol,
} from "../utils/countries.js";

const storageKey = (userId) => `budget-planner-state:${userId}`;

const initialState = {
  transactions: [],
  subscriptions: [],
  savingsGoal: {
    targetAmount: 0,
    currentSavings: 0,
    monthlyContribution: 0,
  },
  monthlyBudget: COUNTRIES[0].defaultBudget,
  countryCode: COUNTRIES[0].code,
};

function budgetReducer(state, action) {
  switch (action.type) {
    case "ADD_TRANSACTION":
      return { ...state, transactions: [action.payload, ...state.transactions] };
    case "ADD_SUBSCRIPTION":
      return { ...state, subscriptions: [action.payload, ...state.subscriptions] };
    case "DELETE_SUBSCRIPTION":
      return {
        ...state,
        subscriptions: state.subscriptions.filter((s) => s.id !== action.payload),
      };
    case "SET_SAVINGS_GOAL":
      return { ...state, savingsGoal: action.payload };
    case "DELETE_TRANSACTION":
      return {
        ...state,
        transactions: state.transactions.filter((t) => t.id !== action.payload),
      };
    case "SET_BUDGET":
      return { ...state, monthlyBudget: action.payload };
    case "SET_COUNTRY": {
      const next = getCountry(action.payload);
      // Reset the budget to a sensible default for the new currency
      return { ...state, countryCode: next.code, monthlyBudget: next.defaultBudget };
    }
    case "CLEAR_ALL":
      return { ...state, transactions: [] };
    default:
      return state;
  }
}

function init(userId) {
  try {
    const saved = localStorage.getItem(storageKey(userId));
    return saved ? { ...initialState, ...JSON.parse(saved) } : initialState;
  } catch {
    return initialState;
  }
}

const BudgetContext = createContext(null);

export function BudgetProvider({ userId, children }) {
  const [state, dispatch] = useReducer(budgetReducer, userId, init);

  // Persist to localStorage whenever state changes
  useEffect(() => {
    try {
      localStorage.setItem(storageKey(userId), JSON.stringify(state));
    } catch {
      /* storage unavailable */
    }
  }, [state, userId]);

  const country = useMemo(() => getCountry(state.countryCode), [state.countryCode]);

  const now = new Date();
  const currentYear = now.getFullYear();
  const currentMonth = now.getMonth();

  const monthlyExpenses = useMemo(
    () =>
      state.transactions
        .filter((transaction) => {
          if (transaction.type !== "expense") return false;
          const date = new Date(transaction.date);
          return (
            !Number.isNaN(date.getTime()) &&
            date.getFullYear() === currentYear &&
            date.getMonth() === currentMonth
          );
        })
        .reduce((sum, transaction) => sum + transaction.amount, 0),
    [state.transactions, currentYear, currentMonth]
  );

  const totals = useMemo(() => {
    const income = state.transactions
      .filter((t) => t.type === "income")
      .reduce((sum, t) => sum + t.amount, 0);
    const expenses = state.transactions
      .filter((t) => t.type === "expense")
      .reduce((sum, t) => sum + t.amount, 0);
    return { income, expenses, balance: income - expenses };
  }, [state.transactions]);

  const value = useMemo(
    () => ({
      ...state,
      country,
      currencySymbol: getCurrencySymbol(country),
      format: (amount) => formatMoney(amount, country),
      monthlyExpenses,
      totals,
      dispatch,
    }),
    [state, country, monthlyExpenses, totals]
  );

  return <BudgetContext.Provider value={value}>{children}</BudgetContext.Provider>;
}

export function useBudget() {
  const ctx = useContext(BudgetContext);
  if (!ctx) throw new Error("useBudget must be used inside <BudgetProvider>");
  return ctx;
}
